package com.example.lumendepths;

import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_7923;

public class LumenItems {

public static final class_1792 LUMEN_SHARD = simple(64);
public static final class_1792 WISP_ESSENCE = simple(64);
public static final class_1792 AURORA_FRUIT = new class_1792(new class_1792.class_1793()
.method_19265(new class_4174.class_4175()
.method_19238(4)
.method_19237(0.4f)
.method_19242()));
// NOTE: lumen_lantern is now a BLOCK (see LumenBlocks.LUMEN_LANTERN + BlockItem).
public static final class_1792 AURORA_GEM = simple(64);
public static final class_1792 CRYSTAL_DUST = simple(64);
public static final class_1792 GLOOM_FANG = simple(64);

private static class_1792 simple(int maxCount) {
return new class_1792(new class_1792.class_1793().method_7889(maxCount));
}

public static void registerItems() {
register("lumen_shard", LUMEN_SHARD);
register("wisp_essence", WISP_ESSENCE);
register("aurora_fruit", AURORA_FRUIT);
register("aurora_gem", AURORA_GEM);
register("crystal_dust", CRYSTAL_DUST);
register("gloom_fang", GLOOM_FANG);
}

public static void register(String name, class_1792 item) {
class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(LumenDepthsMod.MOD_ID, name), item);
LumenDepthsMod.LOGGER.info("[Lumen Depths] Registered item: {}", name);
}
}
