package com.example.lumendepths;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Registers BlockItems for every mod block (same IDs as the blocks). */
public class LumenBlockItems {

private static void register(String name, net.minecraft.class_2248 block) {
class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(LumenDepthsMod.MOD_ID, name),
new class_1747(block, new class_1792.class_1793()));
LumenDepthsMod.LOGGER.info("[Lumen Depths] Registered block item: {}", name);
}

public static void registerBlockItems() {
register("lumen_ore", LumenBlocks.LUMEN_ORE);
register("deepslate_lumen_ore", LumenBlocks.DEEPSLATE_LUMEN_ORE);
register("aurora_ore", LumenBlocks.AURORA_ORE);
register("lumen_crystal_block", LumenBlocks.LUMEN_CRYSTAL_BLOCK);
register("aurora_crystal_block", LumenBlocks.AURORA_CRYSTAL_BLOCK);
register("lumen_crystal_cluster", LumenBlocks.LUMEN_CRYSTAL_CLUSTER);
register("crystal_bricks", LumenBlocks.CRYSTAL_BRICKS);
register("lumen_lantern", LumenBlocks.LUMEN_LANTERN);
}
}
