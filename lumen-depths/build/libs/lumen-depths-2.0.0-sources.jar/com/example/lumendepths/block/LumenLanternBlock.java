package com.example.lumendepths.block;

import net.minecraft.class_2498;
import net.minecraft.class_3620;
import net.minecraft.class_3749;

/**
 * Real lantern block: standing/hanging states, waterlogging, light level 15.
 * Extends the vanilla LanternBlock so all placement/attachment logic is reused.
 */
public class LumenLanternBlock extends class_3749 {

	public LumenLanternBlock(class_2251 settings) {
		super(settings.method_31710(class_3620.field_15991)
				.method_9632(3.5f).method_29292()
				.method_9626(class_2498.field_17734)
				.method_9631(state -> 15));
	}
}
