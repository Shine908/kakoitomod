package com.example.lumendepths.world;

import com.example.lumendepths.LumenDepthsMod;
import com.example.lumendepths.LumenEntities;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_1311;
import net.minecraft.class_1972;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_7924;

/**
 * World generation wiring. The actual ore feature configs live in datapack
 * JSON (data/lumen_depths/worldgen/configured_feature/*.json and
 * placed_feature/*.json); here we reference them by key through the Fabric
 * Biome API and add mob spawn entries in code.
 */
public class LumenWorldgen {

    private static class_5321<class_6796> placed(String name) {
        return class_5321.method_29179(class_7924.field_41245,
                class_2960.method_60655(LumenDepthsMod.MOD_ID, name));
    }

    public static void register() {
        // ---- Ore veins from JSON placed features ----
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, placed("lumen_ore_upper"));
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, placed("lumen_ore_lower"));
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                class_2893.class_2895.field_13176, placed("aurora_ore_deep"));

        // ---- Mob spawn additions ----
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(
                        class_1972.field_9475, class_1972.field_35118, class_1972.field_9417),
                class_1311.field_6303, LumenEntities.GLOWMOTH, 10, 2, 4);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(),
                class_1311.field_6303, LumenEntities.LUMEN_SPRITE, 6, 1, 3);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(
                        class_1972.field_9451, class_1972.field_9455, class_1972.field_34470),
                class_1311.field_6294, LumenEntities.CRYSTAL_SNAIL, 4, 2, 3);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(),
                class_1311.field_6294, LumenEntities.CRYSTAL_BEETLE, 5, 2, 3);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(),
                class_1311.field_6302, LumenEntities.SHARD_WRAITH, 4, 1, 2);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(),
                class_1311.field_6302, LumenEntities.GLOOM_MAW, 6, 1, 3);

        LumenDepthsMod.LOGGER.info("[Lumen Depths] World generation hooks registered");
    }
}
