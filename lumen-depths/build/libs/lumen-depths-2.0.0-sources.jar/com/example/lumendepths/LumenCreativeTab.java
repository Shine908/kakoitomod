package com.example.lumendepths;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public class LumenCreativeTab {

public static final class_5321<class_1761> MAIN_KEY =
class_5321.method_29179(class_7923.field_44687.method_30517(), class_2960.method_60655(LumenDepthsMod.MOD_ID, "main"));

private static final class_1761 MAIN = FabricItemGroup.builder()
.method_47321(class_2561.method_43471("itemGroup.lumen_depths.main"))
.method_47320(() -> new class_1799(LumenBlocks.LUMEN_CRYSTAL_BLOCK))
.method_47317((context, entries) -> {
// Resources & food
entries.method_45421(LumenItems.LUMEN_SHARD);
entries.method_45421(LumenItems.WISP_ESSENCE);
entries.method_45421(LumenItems.AURORA_FRUIT);
entries.method_45421(LumenItems.AURORA_GEM);
entries.method_45421(LumenItems.CRYSTAL_DUST);
entries.method_45421(LumenItems.GLOOM_FANG);
// Blocks
entries.method_45421(LumenBlocks.LUMEN_ORE);
entries.method_45421(LumenBlocks.DEEPSLATE_LUMEN_ORE);
entries.method_45421(LumenBlocks.AURORA_ORE);
entries.method_45421(LumenBlocks.LUMEN_CRYSTAL_BLOCK);
entries.method_45421(LumenBlocks.AURORA_CRYSTAL_BLOCK);
entries.method_45421(LumenBlocks.LUMEN_CRYSTAL_CLUSTER);
entries.method_45421(LumenBlocks.CRYSTAL_BRICKS);
entries.method_45421(LumenBlocks.LUMEN_LANTERN);
// Spawn eggs
entries.method_45421(LumenEntities.GLOWMOTH_SPAWN_EGG);
entries.method_45421(LumenEntities.CRYSTAL_SNAIL_SPAWN_EGG);
entries.method_45421(LumenEntities.LUMEN_SPRITE_SPAWN_EGG);
entries.method_45421(LumenEntities.CRYSTAL_BEETLE_SPAWN_EGG);
entries.method_45421(LumenEntities.SHARD_WRAITH_SPAWN_EGG);
entries.method_45421(LumenEntities.GLOOM_MAW_SPAWN_EGG);
})
.method_47324();

public static void register() {
class_2378.method_39197(class_7923.field_44687, MAIN_KEY, MAIN);
LumenDepthsMod.LOGGER.info("[Lumen Depths] Registered creative tab: {}", MAIN_KEY.method_29177());
}
}
