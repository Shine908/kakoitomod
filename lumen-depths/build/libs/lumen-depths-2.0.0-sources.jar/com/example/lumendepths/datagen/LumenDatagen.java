package com.example.lumendepths.datagen;

import com.example.lumendepths.LumenBlocks;
import com.example.lumendepths.LumenItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

/** Generates crafting recipe JSONs into src/generated/resources at build time. */
public class LumenDatagen extends FabricRecipeProvider {

    public LumenDatagen(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registries) {
        super(output, registries);
    }

    @Override
    public void method_10419(class_8790 exporter) {
        class_2447.method_10437(class_7800.field_40634, LumenBlocks.LUMEN_CRYSTAL_BLOCK)
                .method_10439("##").method_10439("##")
                .method_10434('#', LumenItems.LUMEN_SHARD)
                .method_10429("has_shard", method_10426(LumenItems.LUMEN_SHARD))
                .method_10431(exporter);

        class_2447.method_10437(class_7800.field_40634, LumenBlocks.AURORA_CRYSTAL_BLOCK)
                .method_10439("##").method_10439("##")
                .method_10434('#', LumenItems.AURORA_GEM)
                .method_10429("has_gem", method_10426(LumenItems.AURORA_GEM))
                .method_10431(exporter);

        class_2447.method_10437(class_7800.field_40635, LumenBlocks.LUMEN_LANTERN)
                .method_10439("/").method_10439("#")
                .method_10434('/', class_1802.field_8675)
                .method_10434('#', LumenItems.LUMEN_SHARD)
                .method_10429("has_shard", method_10426(LumenItems.LUMEN_SHARD))
                .method_10431(exporter);

        class_2447.method_10436(class_7800.field_40634, LumenBlocks.CRYSTAL_BRICKS, 4)
                .method_10439("##").method_10439("##")
                .method_10434('#', LumenBlocks.LUMEN_CRYSTAL_BLOCK)
                .method_10429("has_crystal_block", method_10426(LumenBlocks.LUMEN_CRYSTAL_BLOCK))
                .method_10431(exporter);

        class_2450.method_10448(class_7800.field_40642, LumenItems.LUMEN_SHARD, 9)
                .method_10454(LumenBlocks.LUMEN_CRYSTAL_BLOCK)
                .method_10442("has_crystal_block", method_10426(LumenBlocks.LUMEN_CRYSTAL_BLOCK))
                .method_10431(exporter);

        class_2450.method_10448(class_7800.field_40642, LumenItems.AURORA_GEM, 9)
                .method_10454(LumenBlocks.AURORA_CRYSTAL_BLOCK)
                .method_10442("has_aurora_block", method_10426(LumenBlocks.AURORA_CRYSTAL_BLOCK))
                .method_10431(exporter);
    }
}
