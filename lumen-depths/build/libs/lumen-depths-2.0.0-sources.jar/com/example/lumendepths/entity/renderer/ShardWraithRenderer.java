package com.example.lumendepths.entity.renderer;

import com.example.lumendepths.LumenDepthsMod;
import com.example.lumendepths.entity.ShardWraithEntity;
import com.example.lumendepths.entity.model.ShardWraithModel;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class ShardWraithRenderer extends class_927<ShardWraithEntity, ShardWraithModel> {

	private static final class_2960 TEXTURE =
			class_2960.method_60655(LumenDepthsMod.MOD_ID, "textures/entity/shard_wraith.png");

	public ShardWraithRenderer(class_5617.class_5618 context) {
		super(context, new ShardWraithModel(context.method_32167(ShardWraithModel.LAYER)), 0.5f);
	}

	@Override
	public class_2960 getTexture(ShardWraithEntity entity) {
		return TEXTURE;
	}
}
