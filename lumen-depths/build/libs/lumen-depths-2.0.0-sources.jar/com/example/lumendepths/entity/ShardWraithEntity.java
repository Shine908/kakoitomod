package com.example.lumendepths.entity;

import com.example.lumendepths.LumenItems;
import com.example.lumendepths.entity.goals.FlyChaseGoal;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1347;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Shard Wraith: a hostile floating ghost made of crystal shards.
 * Chases players in the air and damages them on contact.
 */
public class ShardWraithEntity extends class_1588 {

private int contactAttackCooldown;

public ShardWraithEntity(class_1299<? extends ShardWraithEntity> type, class_1937 world) {
super(type, world);
this.method_5875(true);
}

public static class_5132.class_5133 createAttributes() {
return class_1588.method_26918()
.method_26868(class_5134.field_23716, 16.0)
.method_26868(class_5134.field_23719, 0.2)
.method_26868(class_5134.field_23720, 0.5)
.method_26868(class_5134.field_23721, 3.0);
}

@Override
protected void method_5959() {
this.field_6201.method_6277(0, new class_1347(this));
this.field_6201.method_6277(1, new FlyChaseGoal(this, 1.0));
this.field_6185.method_6277(1, new class_1400<>(this, class_1657.class, true));
}

@Override
public void method_5773() {
super.method_5773();
if (!this.method_37908().method_8608()) {
this.method_5875(true);
if (this.contactAttackCooldown > 0) {
this.contactAttackCooldown--;
}
// Contact damage when touching the target.
var target = this.method_5968();
if (target != null && target.method_5805() && this.contactAttackCooldown == 0
&& this.method_5739(target) < 1.6) {
if (target.method_5643(this.method_37908().method_48963().method_48812(this),
(float) this.method_45325(class_5134.field_23721))) {
class_243 push = target.method_19538().method_1020(this.method_19538()).method_1029().method_1021(0.4);
target.method_18800(push.field_1352, 0.25, push.field_1350);
}
this.contactAttackCooldown = 30;
}
}
}

@Override
protected class_3414 method_5994() {
return class_3417.field_15127;
}

@Override
protected class_3414 method_6011(class_1282 source) {
return class_3417.field_14940;
}

@Override
protected class_3414 method_6002() {
return class_3417.field_15052;
}

@Override
protected void method_16077(class_1282 source, boolean causedByPlayer) {
super.method_16077(source, causedByPlayer);
this.method_5870(LumenItems.LUMEN_SHARD, 1 + this.method_59922().method_43048(2));
if (this.method_59922().method_43057() < 0.5f) {
this.method_5870(LumenItems.WISP_ESSENCE, 1);
}
if (this.method_59922().method_43057() < 0.1f) {
this.method_5870(LumenItems.AURORA_GEM, 1);
}
}
}
