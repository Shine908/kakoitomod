package com.example.lumendepths.entity.model;
import com.example.lumendepths.LumenDepthsMod;

import com.example.lumendepths.entity.GlowmothEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;

/**
 * Simple glowing moth: body, head, two antennae and two flapping wings.
 */
public class GlowmothEntityModel extends class_583<GlowmothEntity> {

	/** Model layer used by the renderer and client initializer. */
	public static final class_5601 LAYER =
			new class_5601(class_2960.method_60655(LumenDepthsMod.MOD_ID, "glowmoth"), "main");

        private final class_630 body;
        private final class_630 head;
        private final class_630 leftWing;
        private final class_630 rightWing;

        public GlowmothEntityModel(class_630 root) {
                this.body = root.method_32086("body");
                this.head = root.method_32086("head");
                this.leftWing = root.method_32086("left_wing");
                this.rightWing = root.method_32086("right_wing");
        }

        public static class_5607 getTexturedModelData() {
                class_5609 modelData = new class_5609();
                class_5610 root = modelData.method_32111();

                root.method_32117("body", class_5606.method_32108()
                                .method_32101(0, 0)
                                .method_32098(-1.5f, -1.0f, -3.0f, 3.0f, 2.0f, 6.0f, class_5605.field_27715),
                                class_5603.method_32090(0.0f, 12.0f, 0.0f));

                root.method_32117("head", class_5606.method_32108()
                                .method_32101(0, 8)
                                .method_32098(-1.5f, -1.5f, -2.0f, 3.0f, 3.0f, 2.0f, class_5605.field_27715)
                                .method_32101(12, 0)
                                .method_32098(-2.0f, -3.5f, -1.5f, 1.0f, 2.0f, 1.0f, class_5605.field_27715)
                                .method_32101(17, 0)
                                .method_32098(1.0f, -3.5f, -1.5f, 1.0f, 2.0f, 1.0f, class_5605.field_27715),
                                class_5603.method_32090(0.0f, 12.0f, -3.0f));

                root.method_32117("left_wing", class_5606.method_32108()
                                .method_32101(12, 4)
                                .method_32098(0.0f, -0.5f, -3.0f, 6.0f, 1.0f, 6.0f, class_5605.field_27715),
                                class_5603.method_32090(1.5f, 11.5f, 0.0f));

                root.method_32117("right_wing", class_5606.method_32108()
                                .method_32101(12, 4)
                                .method_32096().method_32098(-6.0f, -0.5f, -3.0f, 6.0f, 1.0f, 6.0f, class_5605.field_27715),
                                class_5603.method_32090(-1.5f, 11.5f, 0.0f));

                return class_5607.method_32110(modelData, 64, 64);
        }

        @Override
        public void setAngles(GlowmothEntity entity, float limbSwing, float limbSwingAmount,
                        float ageInTicks, float netHeadYaw, float headPitch) {
                this.head.field_3675 = netHeadYaw * class_3532.field_29847;
                this.head.field_3654 = headPitch * class_3532.field_29847;
                float flap = class_3532.method_15374(ageInTicks * 1.4f) * 0.9f;
                this.leftWing.field_3674 = -flap;
                this.rightWing.field_3674 = flap;
                this.body.field_3654 = 0.1f + class_3532.method_15374(ageInTicks * 0.4f) * 0.05f;
        }


	@Override
	public void method_2828(net.minecraft.class_4587 matrixStack, net.minecraft.class_4588 vertexConsumer, int light, int overlay, int color) {
		this.body.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.head.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.leftWing.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.rightWing.method_22699(matrixStack, vertexConsumer, light, overlay, color);
	}
}
