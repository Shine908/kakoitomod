package com.example.lumendepths.entity;

import com.example.lumendepths.LumenItems;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Gloom Maw: a fast hostile cave predator attacking players in melee.
 */
public class GloomMawEntity extends class_1588 {

public GloomMawEntity(class_1299<? extends GloomMawEntity> type, class_1937 world) {
super(type, world);
}

public static class_5132.class_5133 createAttributes() {
return class_1588.method_26918()
.method_26868(class_5134.field_23716, 20.0)
.method_26868(class_5134.field_23719, 0.28)
.method_26868(class_5134.field_23721, 4.0)
.method_26868(class_5134.field_23724, 2.0);
}

@Override
protected void method_5959() {
this.field_6201.method_6277(0, new class_1347(this));
this.field_6201.method_6277(1, new class_1366(this, 1.15, true));
this.field_6201.method_6277(4, new class_1394(this, 0.9));
this.field_6201.method_6277(5, new class_1361(this, class_1657.class, 10.0f));
this.field_6201.method_6277(6, new class_1376(this));
this.field_6185.method_6277(1, new class_1400<>(this, class_1657.class, true));
}

@Override
protected class_3414 method_5994() {
return class_3417.field_14569;
}

@Override
protected class_3414 method_6011(class_1282 source) {
return class_3417.field_14940;
}

@Override
protected class_3414 method_6002() {
return class_3417.field_14973;
}

@Override
protected void method_16077(class_1282 source, boolean causedByPlayer) {
super.method_16077(source, causedByPlayer);
this.method_5870(LumenItems.GLOOM_FANG, 1 + this.method_59922().method_43048(2));
if (this.method_59922().method_43057() < 0.4f) {
this.method_5870(LumenItems.LUMEN_SHARD, 1);
}
}
}
