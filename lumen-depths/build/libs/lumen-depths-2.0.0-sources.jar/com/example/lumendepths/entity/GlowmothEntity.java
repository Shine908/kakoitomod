package com.example.lumendepths.entity;

import com.example.lumendepths.LumenItems;
import com.example.lumendepths.entity.goals.FlyAroundGoal;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1347;
import net.minecraft.class_1421;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Glowmoth: a small glowing ambient moth that actively flies around caves.
 * Uses direct velocity steering (FlyAroundGoal) with gravity disabled.
 */
public class GlowmothEntity extends class_1421 {

public GlowmothEntity(class_1299<? extends GlowmothEntity> type, class_1937 world) {
super(type, world);
this.method_5875(true);
}

public static class_5132.class_5133 createAttributes() {
return class_1421.method_26828()
.method_26868(class_5134.field_23716, 6.0)
.method_26868(class_5134.field_23719, 0.2)
.method_26868(class_5134.field_23720, 0.6);
}

@Override
protected void method_5959() {
this.field_6201.method_6277(1, new class_1347(this));
this.field_6201.method_6277(2, new FlyAroundGoal(this));
}

@Override
public void method_5773() {
super.method_5773();
if (!this.method_37908().method_8608()) {
this.method_5875(true);
// Occasionally emit a soft glow particle while flying.
if (this.field_6012 % 25 == 0 && !this.method_18798().equals(net.minecraft.class_243.field_1353)) {
((net.minecraft.class_3218) this.method_37908())
.method_14199(class_2398.field_11207,
this.method_23317(), this.method_23318() + 0.3, this.method_23321(), 1, 0.1, 0.1, 0.1, 0.0);
}
}
}

@Override
protected class_3414 method_5994() {
return class_3417.field_28393;
}

@Override
protected class_3414 method_6011(class_1282 source) {
return class_3417.field_14940;
}

@Override
protected class_3414 method_6002() {
return class_3417.field_28394;
}

@Override
protected void method_16077(class_1282 source, boolean causedByPlayer) {
super.method_16077(source, causedByPlayer);
if (causedByPlayer) {
this.method_5870(LumenItems.WISP_ESSENCE, 1 + this.method_59922().method_43048(2));
if (this.method_59922().method_43057() < 0.25f) {
this.method_5870(LumenItems.LUMEN_SHARD, 1);
}
}
}
}
