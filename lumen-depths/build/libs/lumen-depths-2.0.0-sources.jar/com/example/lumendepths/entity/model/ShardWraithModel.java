package com.example.lumendepths.entity.model;

import com.example.lumendepths.LumenDepthsMod;
import com.example.lumendepths.entity.ShardWraithEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;

/**
 * Floating hooded ghost made of shards: torso, head, two dangling arms and
 * orbiting shard fins.
 */
public class ShardWraithModel extends class_583<ShardWraithEntity> {

	public static final class_5601 LAYER =
			new class_5601(class_2960.method_60655(LumenDepthsMod.MOD_ID, "shard_wraith"), "main");

	private final class_630 body;
	private final class_630 head;
	private final class_630 armL;
	private final class_630 armR;
	private final class_630 shards;

	public ShardWraithModel(class_630 root) {
		this.body = root.method_32086("body");
		this.head = root.method_32086("head");
		this.armL = root.method_32086("arm_l");
		this.armR = root.method_32086("arm_r");
		this.shards = root.method_32086("shards");
	}

	public static class_5607 getTexturedModelData() {
		class_5609 modelData = new class_5609();
		class_5610 root = modelData.method_32111();

		root.method_32117("body", class_5606.method_32108()
						.method_32101(0, 0)
						.method_32098(-4.0f, 0.0f, -2.5f, 8.0f, 12.0f, 5.0f, class_5605.field_27715),
				class_5603.method_32090(0.0f, 8.0f, 0.0f));

		root.method_32117("head", class_5606.method_32108()
						.method_32101(0, 17)
						.method_32098(-4.0f, -6.0f, -4.0f, 8.0f, 8.0f, 8.0f, class_5605.field_27715),
				class_5603.method_32090(0.0f, 8.0f, 0.0f));

		root.method_32117("arm_l", class_5606.method_32108()
						.method_32101(24, 17)
						.method_32098(0.0f, 0.0f, -2.0f, 3.0f, 10.0f, 3.0f, class_5605.field_27715),
				class_5603.method_32090(4.5f, 9.0f, 0.0f));

		root.method_32117("arm_r", class_5606.method_32108()
						.method_32101(24, 30)
						.method_32096().method_32098(-3.0f, 0.0f, -2.0f, 3.0f, 10.0f, 3.0f, class_5605.field_27715),
				class_5603.method_32090(-4.5f, 9.0f, 0.0f));

		root.method_32117("shards", class_5606.method_32108()
						.method_32101(40, 0)
						.method_32098(-1.0f, -1.0f, -7.0f, 2.0f, 6.0f, 2.0f, class_5605.field_27715)
						.method_32101(40, 8)
						.method_32098(-1.0f, -1.0f, 5.0f, 2.0f, 6.0f, 2.0f, class_5605.field_27715),
				class_5603.method_32090(0.0f, 10.0f, 0.0f));

		return class_5607.method_32110(modelData, 64, 64);
	}

	@Override
	public void setAngles(ShardWraithEntity entity, float limbSwing, float limbSwingAmount,
			float ageInTicks, float netHeadYaw, float headPitch) {
		this.head.field_3675 = netHeadYaw * class_3532.field_29847;
		this.head.field_3654 = headPitch * class_3532.field_29847;
		float bob = class_3532.method_15374(ageInTicks * 0.3f);
		this.armL.field_3654 = bob * 0.4f - 0.2f;
		this.armR.field_3654 = -bob * 0.4f - 0.2f;
		this.shards.field_3675 = ageInTicks * 0.25f;
		this.body.field_3654 = 0.05f + class_3532.method_15374(ageInTicks * 0.15f) * 0.03f;
	}


	@Override
	public void method_2828(net.minecraft.class_4587 matrixStack, net.minecraft.class_4588 vertexConsumer, int light, int overlay, int color) {
		this.body.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.head.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.armL.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.armR.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.shards.method_22699(matrixStack, vertexConsumer, light, overlay, color);
	}
}
