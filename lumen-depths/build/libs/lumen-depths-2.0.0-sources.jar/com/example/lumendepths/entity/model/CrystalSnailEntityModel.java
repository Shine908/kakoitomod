package com.example.lumendepths.entity.model;
import com.example.lumendepths.LumenDepthsMod;

import com.example.lumendepths.entity.CrystalSnailEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;

/**
 * Snail with a soft foot base, a big crystal shell and two eye stalks.
 */
public class CrystalSnailEntityModel extends class_583<CrystalSnailEntity> {

	/** Model layer used by the renderer and client initializer. */
	public static final class_5601 LAYER =
			new class_5601(class_2960.method_60655(LumenDepthsMod.MOD_ID, "crystal_snail"), "main");

        private final class_630 foot;
        private final class_630 head;
        private final class_630 shell;
        private final class_630 leftHorn;
        private final class_630 rightHorn;

        public CrystalSnailEntityModel(class_630 root) {
                this.foot = root.method_32086("foot");
                this.head = root.method_32086("head");
                this.shell = root.method_32086("shell");
                this.leftHorn = root.method_32086("left_horn");
                this.rightHorn = root.method_32086("right_horn");
        }

        public static class_5607 getTexturedModelData() {
                class_5609 modelData = new class_5609();
                class_5610 root = modelData.method_32111();

                root.method_32117("foot", class_5606.method_32108()
                                .method_32101(0, 0)
                                .method_32098(-4.0f, -2.0f, -6.0f, 8.0f, 4.0f, 12.0f, class_5605.field_27715),
                                class_5603.method_32090(0.0f, 20.0f, 0.0f));

                root.method_32117("head", class_5606.method_32108()
                                .method_32101(0, 16)
                                .method_32098(-2.0f, -3.0f, -3.0f, 4.0f, 4.0f, 4.0f, class_5605.field_27715),
                                class_5603.method_32090(0.0f, 18.0f, -6.0f));

                root.method_32117("shell", class_5606.method_32108()
                                .method_32101(16, 16)
                                .method_32098(-4.0f, -7.0f, -4.0f, 8.0f, 8.0f, 8.0f, class_5605.field_27715)
                                .method_32101(20, 32)
                                .method_32098(-2.0f, -9.0f, -2.0f, 4.0f, 3.0f, 4.0f, class_5605.field_27715),
                                class_5603.method_32090(0.0f, 15.0f, 1.0f));

                root.method_32117("left_horn", class_5606.method_32108()
                                .method_32101(40, 8)
                                .method_32098(-0.5f, -4.0f, -0.5f, 1.0f, 4.0f, 1.0f, class_5605.field_27715),
                                class_5603.method_32090(1.5f, 15.0f, -7.0f));

                root.method_32117("right_horn", class_5606.method_32108()
                                .method_32101(40, 8)
                                .method_32098(-0.5f, -4.0f, -0.5f, 1.0f, 4.0f, 1.0f, class_5605.field_27715),
                                class_5603.method_32090(-1.5f, 15.0f, -7.0f));

                return class_5607.method_32110(modelData, 64, 64);
        }

        @Override
        public void setAngles(CrystalSnailEntity entity, float limbSwing, float limbSwingAmount,
                        float ageInTicks, float netHeadYaw, float headPitch) {
                this.head.field_3675 = netHeadYaw * class_3532.field_29847;
                this.head.field_3654 = headPitch * class_3532.field_29847;
                this.leftHorn.field_3654 = this.head.field_3654;
                this.rightHorn.field_3654 = this.head.field_3654;
                this.leftHorn.field_3675 = class_3532.method_15374(ageInTicks * 0.3f) * 0.15f;
                this.rightHorn.field_3675 = -class_3532.method_15374(ageInTicks * 0.3f) * 0.15f;
                float scale = entity.method_6109() ? 0.6f : 1.0f;
                this.shell.field_37938 = scale;
                this.shell.field_37939 = scale;
                this.shell.field_37940 = scale;
        }


	@Override
	public void method_2828(net.minecraft.class_4587 matrixStack, net.minecraft.class_4588 vertexConsumer, int light, int overlay, int color) {
		this.foot.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.head.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.shell.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.leftHorn.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.rightHorn.method_22699(matrixStack, vertexConsumer, light, overlay, color);
	}
}
