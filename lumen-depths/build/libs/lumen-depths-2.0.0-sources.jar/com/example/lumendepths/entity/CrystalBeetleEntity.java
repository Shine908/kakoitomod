package com.example.lumendepths.entity;

import com.example.lumendepths.LumenItems;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1314;
import net.minecraft.class_1338;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Crystal Beetle: a slow, shy passive ground creature of the Lumen Caves.
 */
public class CrystalBeetleEntity extends class_1314 {

public CrystalBeetleEntity(class_1299<? extends CrystalBeetleEntity> type, class_1937 world) {
super(type, world);
}

public static class_5132.class_5133 createAttributes() {
return class_1308.method_26828()
.method_26868(class_5134.field_23716, 8.0)
.method_26868(class_5134.field_23719, 0.18)
.method_26868(class_5134.field_23724, 2.0);
}

@Override
protected void method_5959() {
this.field_6201.method_6277(0, new class_1347(this));
this.field_6201.method_6277(1, new class_1338<>(this, class_1657.class, 8.0f, 1.2, 1.5));
this.field_6201.method_6277(4, new class_1394(this, 0.8));
this.field_6201.method_6277(5, new class_1361(this, class_1657.class, 5.0f));
this.field_6201.method_6277(6, new class_1376(this));
}

@Override
protected class_3414 method_5994() {
return class_3417.field_15137;
}

@Override
protected class_3414 method_6011(class_1282 source) {
return class_3417.field_14940;
}

@Override
protected class_3414 method_6002() {
return class_3417.field_15230;
}

@Override
protected void method_16077(class_1282 source, boolean causedByPlayer) {
super.method_16077(source, causedByPlayer);
this.method_5870(LumenItems.CRYSTAL_DUST, 1 + this.method_59922().method_43048(2));
if (this.method_59922().method_43057() < 0.25f) {
this.method_5870(LumenItems.LUMEN_SHARD, 1);
}
}
}
