package com.example.lumendepths.entity.goals;

import java.util.EnumSet;
import net.minecraft.class_1308;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import net.minecraft.class_243;

/**
 * Simple custom flying wander goal: picks a random air position near the mob
 * and steers toward it using direct velocity control (no pathfinding needed).
 */
public class FlyAroundGoal extends class_1352 {

private final class_1308 entity;
private class_243 target;
private int restTicks;

public FlyAroundGoal(class_1308 entity) {
this.entity = entity;
this.method_6265(EnumSet.of(class_1352.class_4134.field_18405, class_1352.class_4134.field_18406));
}

@Override
public boolean method_6264() {
return this.target == null && this.restTicks <= 0;
}

@Override
public void method_6269() {
class_243 pos = this.entity.method_19538();
double r = 6.0 + this.entity.method_59922().method_43058() * 8.0;
double angle = this.entity.method_59922().method_43058() * Math.PI * 2.0;
class_2338 next = class_2338.method_49637(
pos.field_1352 + Math.cos(angle) * r,
pos.field_1351 + (this.entity.method_59922().method_43058() - 0.5) * 4.0,
pos.field_1350 + Math.sin(angle) * r);
this.target = class_243.method_24953(next);
}

@Override
public boolean method_6266() {
return this.target != null;
}

@Override
public void method_6268() {
if (this.restTicks > 0) {
this.restTicks--;
}
if (this.target == null) {
return;
}
class_243 delta = this.target.method_1020(this.entity.method_19538());
if (delta.method_1027() < 1.0) {
this.target = null;
this.restTicks = 20 + this.entity.method_59922().method_43048(60);
return;
}
class_243 move = delta.method_1029().method_1021(0.07);
this.entity.method_18799(move);
this.entity.method_36456((float) Math.toDegrees(-Math.atan2(move.field_1352, move.field_1350)));
this.entity.method_36457((float) Math.toDegrees(-Math.atan2(move.field_1351, Math.hypot(move.field_1352, move.field_1350))));
}

public void end() {
this.target = null;
}

}
