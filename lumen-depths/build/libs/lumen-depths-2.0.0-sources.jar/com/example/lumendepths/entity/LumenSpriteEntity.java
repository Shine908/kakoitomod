package com.example.lumendepths.entity;

import com.example.lumendepths.LumenItems;
import com.example.lumendepths.entity.goals.FlyAroundGoal;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1347;
import net.minecraft.class_1421;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Lumen Sprite: a passive glowing flying spirit of the Lumen Caves.
 */
public class LumenSpriteEntity extends class_1421 {

public LumenSpriteEntity(class_1299<? extends LumenSpriteEntity> type, class_1937 world) {
super(type, world);
this.method_5875(true);
}

public static class_5132.class_5133 createAttributes() {
return class_1421.method_26828()
.method_26868(class_5134.field_23716, 4.0)
.method_26868(class_5134.field_23719, 0.2)
.method_26868(class_5134.field_23720, 0.7);
}

@Override
protected void method_5959() {
this.field_6201.method_6277(1, new class_1347(this));
this.field_6201.method_6277(2, new FlyAroundGoal(this));
}

@Override
public void method_5773() {
super.method_5773();
if (!this.method_37908().method_8608()) {
this.method_5875(true);
if (this.field_6012 % 12 == 0) {
((net.minecraft.class_3218) this.method_37908())
.method_14199(class_2398.field_11214,
this.method_23317(), this.method_23318() + 0.4, this.method_23321(), 2, 0.2, 0.2, 0.2, 0.02);
}
}
}

@Override
protected class_3414 method_5994() {
return class_3417.field_28393;
}

@Override
protected class_3414 method_6011(class_1282 source) {
return class_3417.field_14940;
}

@Override
protected class_3414 method_6002() {
return class_3417.field_15230;
}

@Override
protected void method_16077(class_1282 source, boolean causedByPlayer) {
super.method_16077(source, causedByPlayer);
if (causedByPlayer) {
this.method_5870(LumenItems.WISP_ESSENCE, 1 + this.method_59922().method_43048(2));
if (this.method_59922().method_43057() < 0.3f) {
this.method_5870(LumenItems.CRYSTAL_DUST, 1);
}
}
}
}
