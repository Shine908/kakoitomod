package com.example.lumendepths.entity.renderer;

import com.example.lumendepths.LumenDepthsMod;
import com.example.lumendepths.entity.CrystalSnailEntity;
import com.example.lumendepths.entity.model.CrystalSnailEntityModel;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class CrystalSnailEntityRenderer extends class_927<CrystalSnailEntity, CrystalSnailEntityModel> {

        private static final class_2960 TEXTURE =
                        class_2960.method_60655(LumenDepthsMod.MOD_ID, "textures/entity/crystal_snail.png");

        public CrystalSnailEntityRenderer(class_5617.class_5618 context) {
                super(context, new CrystalSnailEntityModel(context.method_32167(CrystalSnailEntityModel.LAYER)), 0.4f);
        }

        @Override
        public class_2960 getTexture(CrystalSnailEntity entity) {
                return TEXTURE;
        }
}
