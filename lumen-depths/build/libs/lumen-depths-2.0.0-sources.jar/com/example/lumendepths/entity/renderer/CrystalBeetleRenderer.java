package com.example.lumendepths.entity.renderer;

import com.example.lumendepths.LumenDepthsMod;
import com.example.lumendepths.entity.CrystalBeetleEntity;
import com.example.lumendepths.entity.model.CrystalBeetleModel;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class CrystalBeetleRenderer extends class_927<CrystalBeetleEntity, CrystalBeetleModel> {

	private static final class_2960 TEXTURE =
			class_2960.method_60655(LumenDepthsMod.MOD_ID, "textures/entity/crystal_beetle.png");

	public CrystalBeetleRenderer(class_5617.class_5618 context) {
		super(context, new CrystalBeetleModel(context.method_32167(CrystalBeetleModel.LAYER)), 0.4f);
	}

	@Override
	public class_2960 getTexture(CrystalBeetleEntity entity) {
		return TEXTURE;
	}
}
