package com.example.lumendepths.entity;

import com.example.lumendepths.LumenEntities;
import com.example.lumendepths.LumenItems;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1353;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Crystal Snail: a slow, passive creature with a glowing crystal shell.
 */
public class CrystalSnailEntity extends class_1429 {

	public CrystalSnailEntity(class_1299<? extends CrystalSnailEntity> type, class_1937 world) {
		super(type, world);
	}

	public static class_5132.class_5133 createAttributes() {
		return class_1429.method_26828()
				.method_26868(class_5134.field_23716, 10.0)
				.method_26868(class_5134.field_23719, 0.12);
	}

	@Override
	protected void method_5959() {
		this.field_6201.method_6277(0, new class_1347(this));
		this.field_6201.method_6277(1, new class_1341(this, 1.0));
		this.field_6201.method_6277(2, new class_1391(this, 1.1, CrystalSnailEntity::isTemptItem, false));
		this.field_6201.method_6277(3, new class_1353(this, 1.0));
		this.field_6201.method_6277(4, new class_1394(this, 1.0));
		this.field_6201.method_6277(5, new class_1361(this, class_1657.class, 6.0f));
		this.field_6201.method_6277(6, new class_1376(this));
	}

	private static boolean isTemptItem(class_1799 stack) {
		return stack.method_31574(class_1802.field_8479) || stack.method_31574(LumenItems.AURORA_FRUIT);
	}

	@Override
	public boolean method_6481(class_1799 stack) {
		return stack.method_31574(class_1802.field_8479);
	}

	@Override
	public class_1296 method_5613(class_3218 world, class_1296 parent) {
		CrystalSnailEntity child = LumenEntities.CRYSTAL_SNAIL.method_5883(world);
		if (child != null) {
			child.method_6033(child.method_6063());
		}
		return child;
	}

	@Override
	protected class_3414 method_5994() {
		return class_3417.field_15180;
	}

	@Override
	protected class_3414 method_6011(class_1282 source) {
		return class_3417.field_14940;
	}

	@Override
	protected class_3414 method_6002() {
		return class_3417.field_14856;
	}

	@Override
	protected void method_16077(class_1282 source, boolean causedByPlayer) {
		super.method_16077(source, causedByPlayer);
		int count = 1 + this.method_59922().method_43048(2);
		this.method_5870(LumenItems.LUMEN_SHARD, count);
		if (this.method_59922().method_43057() < 0.2f) {
			this.method_5870(LumenItems.WISP_ESSENCE, 1);
		}
	}
}
