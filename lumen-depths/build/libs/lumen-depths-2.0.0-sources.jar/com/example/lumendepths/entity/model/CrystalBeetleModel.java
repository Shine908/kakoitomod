package com.example.lumendepths.entity.model;

import com.example.lumendepths.LumenDepthsMod;
import com.example.lumendepths.entity.CrystalBeetleEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;

/**
 * Low, wide beetle with a segmented glowing shell and tiny legs.
 */
public class CrystalBeetleModel extends class_583<CrystalBeetleEntity> {

	public static final class_5601 LAYER =
			new class_5601(class_2960.method_60655(LumenDepthsMod.MOD_ID, "crystal_beetle"), "main");

	private final class_630 body;
	private final class_630 head;
	private final class_630 legL;
	private final class_630 legR;

	public CrystalBeetleModel(class_630 root) {
		this.body = root.method_32086("body");
		this.head = root.method_32086("head");
		this.legL = root.method_32086("legs_l");
		this.legR = root.method_32086("legs_r");
	}

	public static class_5607 getTexturedModelData() {
		class_5609 modelData = new class_5609();
		class_5610 root = modelData.method_32111();

		root.method_32117("body", class_5606.method_32108()
						.method_32101(0, 0)
						.method_32098(-4.0f, -3.0f, -5.0f, 8.0f, 4.0f, 10.0f, class_5605.field_27715)
						.method_32101(0, 14)
						.method_32098(-2.5f, -4.5f, -3.0f, 5.0f, 2.0f, 6.0f, class_5605.field_27715),
				class_5603.method_32090(0.0f, 19.0f, 0.0f));

		root.method_32117("head", class_5606.method_32108()
						.method_32101(26, 0)
						.method_32098(-2.5f, -2.0f, -3.0f, 5.0f, 4.0f, 3.0f, class_5605.field_27715)
						.method_32101(26, 10)
						.method_32098(-3.5f, -2.5f, -2.0f, 1.0f, 1.0f, 2.0f, class_5605.field_27715)
						.method_32101(32, 10)
						.method_32098(2.5f, -2.5f, -2.0f, 1.0f, 1.0f, 2.0f, class_5605.field_27715),
				class_5603.method_32090(0.0f, 19.0f, -5.0f));

		root.method_32117("legs_l", class_5606.method_32108()
						.method_32101(40, 0)
						.method_32098(0.0f, 0.0f, -4.0f, 1.0f, 3.0f, 1.0f, class_5605.field_27715)
						.method_32098(0.0f, 0.0f, 0.0f, 1.0f, 3.0f, 1.0f, class_5605.field_27715)
						.method_32098(0.0f, 0.0f, 3.0f, 1.0f, 3.0f, 1.0f, class_5605.field_27715),
				class_5603.method_32090(4.0f, 20.0f, 0.0f));

		root.method_32117("legs_r", class_5606.method_32108()
						.method_32101(40, 8)
						.method_32096().method_32098(-1.0f, 0.0f, -4.0f, 1.0f, 3.0f, 1.0f, class_5605.field_27715)
						.method_32098(-1.0f, 0.0f, 0.0f, 1.0f, 3.0f, 1.0f, class_5605.field_27715)
						.method_32098(-1.0f, 0.0f, 3.0f, 1.0f, 3.0f, 1.0f, class_5605.field_27715),
				class_5603.method_32090(-4.0f, 20.0f, 0.0f));

		return class_5607.method_32110(modelData, 64, 64);
	}

	@Override
	public void setAngles(CrystalBeetleEntity entity, float limbSwing, float limbSwingAmount,
			float ageInTicks, float netHeadYaw, float headPitch) {
		this.head.field_3675 = netHeadYaw * class_3532.field_29847;
		this.head.field_3654 = headPitch * class_3532.field_29847;
		float swing = class_3532.method_15362(limbSwing * 0.6662f) * 0.4f * limbSwingAmount;
		this.legL.field_3674 = swing;
		this.legR.field_3674 = -swing;
	}


	@Override
	public void method_2828(net.minecraft.class_4587 matrixStack, net.minecraft.class_4588 vertexConsumer, int light, int overlay, int color) {
		this.body.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.head.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.legL.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.legR.method_22699(matrixStack, vertexConsumer, light, overlay, color);
	}
}
