package com.example.lumendepths.entity.renderer;

import com.example.lumendepths.LumenDepthsMod;
import com.example.lumendepths.entity.LumenSpriteEntity;
import com.example.lumendepths.entity.model.LumenSpriteModel;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class LumenSpriteRenderer extends class_927<LumenSpriteEntity, LumenSpriteModel> {

	private static final class_2960 TEXTURE =
			class_2960.method_60655(LumenDepthsMod.MOD_ID, "textures/entity/lumen_sprite.png");

	public LumenSpriteRenderer(class_5617.class_5618 context) {
		super(context, new LumenSpriteModel(context.method_32167(LumenSpriteModel.LAYER)), 0.3f);
	}

	@Override
	public class_2960 getTexture(LumenSpriteEntity entity) {
		return TEXTURE;
	}
}
