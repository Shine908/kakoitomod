package com.example.lumendepths.entity.goals;

import java.util.EnumSet;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_243;

/**
 * Simple air chase goal: steers the mob directly toward its target using
 * velocity (no ground pathfinding). Works together with no-gravity mobs.
 */
public class FlyChaseGoal extends class_1352 {

private final class_1308 entity;
private final double speed;
private class_1309 target;

public FlyChaseGoal(class_1308 entity, double speed) {
this.entity = entity;
this.speed = speed;
this.method_6265(EnumSet.of(class_1352.class_4134.field_18405, class_1352.class_4134.field_18406));
}

@Override
public boolean method_6264() {
class_1309 t = this.entity.method_5968();
return t != null && t.method_5805() && t.method_5858(this.entity) > 1.0;
}

@Override
public void method_6269() {
this.target = this.entity.method_5968();
}

@Override
public boolean method_6266() {
return this.target != null && this.target.method_5805();
}

@Override
public void method_6268() {
if (this.target == null) {
return;
}
class_243 delta = this.target.method_19538().method_1031(0, 0.4, 0).method_1020(this.entity.method_19538());
double len = delta.method_1033();
if (len < 0.0001) {
return;
}
class_243 move = delta.method_1029().method_1021(this.speed * 0.09);
this.entity.method_18799(move);
this.entity.method_36456((float) Math.toDegrees(-Math.atan2(move.field_1352, move.field_1350)));
this.entity.method_36457((float) Math.toDegrees(-Math.atan2(move.field_1351, Math.hypot(move.field_1352, move.field_1350))));
}

public void end() {
this.target = null;
}
}
