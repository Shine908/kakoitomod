package com.example.lumendepths.entity.renderer;

import com.example.lumendepths.LumenDepthsMod;
import com.example.lumendepths.entity.GlowmothEntity;
import com.example.lumendepths.entity.model.GlowmothEntityModel;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class GlowmothEntityRenderer extends class_927<GlowmothEntity, GlowmothEntityModel> {

        private static final class_2960 TEXTURE =
                        class_2960.method_60655(LumenDepthsMod.MOD_ID, "textures/entity/glowmoth.png");

        public GlowmothEntityRenderer(class_5617.class_5618 context) {
                super(context, new GlowmothEntityModel(context.method_32167(GlowmothEntityModel.LAYER)), 0.3f);
        }

        @Override
        public class_2960 getTexture(GlowmothEntity entity) {
                return TEXTURE;
        }
}
