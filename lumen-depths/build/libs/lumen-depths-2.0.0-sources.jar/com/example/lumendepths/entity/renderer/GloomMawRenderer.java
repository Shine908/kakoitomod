package com.example.lumendepths.entity.renderer;

import com.example.lumendepths.LumenDepthsMod;
import com.example.lumendepths.entity.GloomMawEntity;
import com.example.lumendepths.entity.model.GloomMawModel;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class GloomMawRenderer extends class_927<GloomMawEntity, GloomMawModel> {

	private static final class_2960 TEXTURE =
			class_2960.method_60655(LumenDepthsMod.MOD_ID, "textures/entity/gloom_maw.png");

	public GloomMawRenderer(class_5617.class_5618 context) {
		super(context, new GloomMawModel(context.method_32167(GloomMawModel.LAYER)), 0.6f);
	}

	@Override
	public class_2960 getTexture(GloomMawEntity entity) {
		return TEXTURE;
	}
}
