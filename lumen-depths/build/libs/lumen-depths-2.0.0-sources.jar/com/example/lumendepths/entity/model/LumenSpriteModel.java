package com.example.lumendepths.entity.model;

import com.example.lumendepths.LumenDepthsMod;
import com.example.lumendepths.entity.LumenSpriteEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;

/**
 * Floating crystal orb with two drooping tendrils. 64x64 texture.
 */
public class LumenSpriteModel extends class_583<LumenSpriteEntity> {

	public static final class_5601 LAYER =
			new class_5601(class_2960.method_60655(LumenDepthsMod.MOD_ID, "lumen_sprite"), "main");

	private final class_630 body;
	private final class_630 tendrilL;
	private final class_630 tendrilR;

	public LumenSpriteModel(class_630 root) {
		this.body = root.method_32086("body");
		this.tendrilL = root.method_32086("tendril_l");
		this.tendrilR = root.method_32086("tendril_r");
	}

	public static class_5607 getTexturedModelData() {
		class_5609 modelData = new class_5609();
		class_5610 root = modelData.method_32111();

		root.method_32117("body", class_5606.method_32108()
						.method_32101(0, 0)
						.method_32098(-3.0f, -3.0f, -3.0f, 6.0f, 6.0f, 6.0f, class_5605.field_27715),
				class_5603.method_32090(0.0f, 14.0f, 0.0f));

		root.method_32117("tendril_l", class_5606.method_32108()
						.method_32101(24, 0)
						.method_32098(-1.0f, 0.0f, -1.0f, 2.0f, 5.0f, 2.0f, class_5605.field_27715),
				class_5603.method_32090(-2.0f, 15.0f, 0.0f));

		root.method_32117("tendril_r", class_5606.method_32108()
						.method_32101(24, 8)
						.method_32098(-1.0f, 0.0f, -1.0f, 2.0f, 5.0f, 2.0f, class_5605.field_27715),
				class_5603.method_32090(2.0f, 15.0f, 0.0f));

		return class_5607.method_32110(modelData, 64, 64);
	}

	@Override
	public void setAngles(LumenSpriteEntity entity, float limbSwing, float limbSwingAmount,
			float ageInTicks, float netHeadYaw, float headPitch) {
		float sway = class_3532.method_15374(ageInTicks * 0.4f) * 0.2f;
		this.tendrilL.field_3654 = sway;
		this.tendrilR.field_3654 = -sway;
		this.body.field_3675 = netHeadYaw * class_3532.field_29847;
		this.body.field_3654 = headPitch * class_3532.field_29847;
	}


	@Override
	public void method_2828(net.minecraft.class_4587 matrixStack, net.minecraft.class_4588 vertexConsumer, int light, int overlay, int color) {
		this.body.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.tendrilL.method_22699(matrixStack, vertexConsumer, light, overlay, color);
		this.tendrilR.method_22699(matrixStack, vertexConsumer, light, overlay, color);
	}
}
