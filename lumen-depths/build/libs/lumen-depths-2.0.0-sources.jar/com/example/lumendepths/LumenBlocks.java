package com.example.lumendepths;

import com.example.lumendepths.block.LumenLanternBlock;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public class LumenBlocks {

private static class_4970.class_2251 ore(class_3620 color) {
return class_4970.class_2251.method_9637()
.method_31710(color).method_9632(3.0f).method_29292()
.method_9626(class_2498.field_11544);
}

public static final class_2248 LUMEN_ORE = new class_2248(ore(class_3620.field_15978)
.method_9631(state -> 5));
public static final class_2248 DEEPSLATE_LUMEN_ORE = new class_2248(ore(class_3620.field_15978)
.method_9631(state -> 5));
public static final class_2248 AURORA_ORE = new class_2248(ore(class_3620.field_15984)
.method_9632(4.0f).method_9631(state -> 7));

public static final class_2248 LUMEN_CRYSTAL_BLOCK = new class_2248(class_4970.class_2251.method_9637()
.method_31710(class_3620.field_15991)
.method_9632(4.0f).method_29292().method_22488()
.method_9626(class_2498.field_27197)
.method_9631(state -> 12));

public static final class_2248 AURORA_CRYSTAL_BLOCK = new class_2248(class_4970.class_2251.method_9637()
.method_31710(class_3620.field_16029)
.method_9632(4.0f).method_29292().method_22488()
.method_9626(class_2498.field_27197)
.method_9631(state -> 15));

public static final class_2248 LUMEN_CRYSTAL_CLUSTER = new class_2248(class_4970.class_2251.method_9637()
.method_31710(class_3620.field_15991)
.method_9632(2.0f).method_29292().method_22488()
.method_9626(class_2498.field_27197)
.method_9631(state -> 10));

public static final class_2248 CRYSTAL_BRICKS = new class_2248(class_4970.class_2251.method_9637()
.method_31710(class_3620.field_15990)
.method_9629(5.0f, 6.0f).method_29292()
.method_9626(class_2498.field_11544));

public static final class_2248 LUMEN_LANTERN = new LumenLanternBlock(
class_4970.class_2251.method_9637());

private static class_2960 id(String path) {
return class_2960.method_60655(LumenDepthsMod.MOD_ID, path);
}

public static void registerBlocks() {
register("lumen_ore", LUMEN_ORE);
register("deepslate_lumen_ore", DEEPSLATE_LUMEN_ORE);
register("aurora_ore", AURORA_ORE);
register("lumen_crystal_block", LUMEN_CRYSTAL_BLOCK);
register("aurora_crystal_block", AURORA_CRYSTAL_BLOCK);
register("lumen_crystal_cluster", LUMEN_CRYSTAL_CLUSTER);
register("crystal_bricks", CRYSTAL_BRICKS);
register("lumen_lantern", LUMEN_LANTERN);
}

private static void register(String name, class_2248 block) {
class_2378.method_10230(class_7923.field_41175, id(name), block);
LumenDepthsMod.LOGGER.info("[Lumen Depths] Registered block: {}", name);
}
}
