package com.example.lumendepths;

import com.example.lumendepths.entity.CrystalBeetleEntity;
import com.example.lumendepths.entity.CrystalSnailEntity;
import com.example.lumendepths.entity.GlowmothEntity;
import com.example.lumendepths.entity.GloomMawEntity;
import com.example.lumendepths.entity.LumenSpriteEntity;
import com.example.lumendepths.entity.ShardWraithEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class LumenEntities {

public static final class_1299<GlowmothEntity> GLOWMOTH = class_2378.method_10230(
class_7923.field_41177, id("glowmoth"),
class_1299.class_1300.<GlowmothEntity>method_5903(GlowmothEntity::new, class_1311.field_6303)
.method_17687(0.5f, 0.4f).method_27299(8).method_5905("glowmoth"));

public static final class_1299<CrystalSnailEntity> CRYSTAL_SNAIL = class_2378.method_10230(
class_7923.field_41177, id("crystal_snail"),
class_1299.class_1300.<CrystalSnailEntity>method_5903(CrystalSnailEntity::new, class_1311.field_6294)
.method_17687(0.8f, 0.6f).method_27299(8).method_5905("crystal_snail"));

public static final class_1299<LumenSpriteEntity> LUMEN_SPRITE = class_2378.method_10230(
class_7923.field_41177, id("lumen_sprite"),
class_1299.class_1300.<LumenSpriteEntity>method_5903(LumenSpriteEntity::new, class_1311.field_6303)
.method_17687(0.4f, 0.4f).method_27299(8).method_5905("lumen_sprite"));

public static final class_1299<CrystalBeetleEntity> CRYSTAL_BEETLE = class_2378.method_10230(
class_7923.field_41177, id("crystal_beetle"),
class_1299.class_1300.<CrystalBeetleEntity>method_5903(CrystalBeetleEntity::new, class_1311.field_6294)
.method_17687(0.7f, 0.4f).method_27299(8).method_5905("crystal_beetle"));

public static final class_1299<ShardWraithEntity> SHARD_WRAITH = class_2378.method_10230(
class_7923.field_41177, id("shard_wraith"),
class_1299.class_1300.<ShardWraithEntity>method_5903(ShardWraithEntity::new, class_1311.field_6302)
.method_17687(0.7f, 1.6f).method_27299(8).method_5905("shard_wraith"));

public static final class_1299<GloomMawEntity> GLOOM_MAW = class_2378.method_10230(
class_7923.field_41177, id("gloom_maw"),
class_1299.class_1300.<GloomMawEntity>method_5903(GloomMawEntity::new, class_1311.field_6302)
.method_17687(0.9f, 0.8f).method_27299(8).method_5905("gloom_maw"));

// Spawn eggs need a non-null EntityType at construction time in 1.21.1,
// so they are created and registered here, after the entity types above.
public static final class_1792 GLOWMOTH_SPAWN_EGG = registerEgg("glowmoth_spawn_egg", GLOWMOTH, 0x4DEEEA, 0xB39DDB);
public static final class_1792 CRYSTAL_SNAIL_SPAWN_EGG = registerEgg("crystal_snail_spawn_egg", CRYSTAL_SNAIL, 0x7B68EE, 0x87CEEB);
public static final class_1792 LUMEN_SPRITE_SPAWN_EGG = registerEgg("lumen_sprite_spawn_egg", LUMEN_SPRITE, 0xEFFFFF, 0x66E0FF);
public static final class_1792 CRYSTAL_BEETLE_SPAWN_EGG = registerEgg("crystal_beetle_spawn_egg", CRYSTAL_BEETLE, 0x3A5FD0, 0x8A6FE8);
public static final class_1792 SHARD_WRAITH_SPAWN_EGG = registerEgg("shard_wraith_spawn_egg", SHARD_WRAITH, 0x1A1A3E, 0x4DEEEA);
public static final class_1792 GLOOM_MAW_SPAWN_EGG = registerEgg("gloom_maw_spawn_egg", GLOOM_MAW, 0x2B1B3D, 0xD94FFF);

private static <T extends net.minecraft.class_1308> class_1792 registerEgg(
String name, class_1299<T> type, int primary, int secondary) {
return class_2378.method_10230(class_7923.field_41178, id(name),
new class_1826(type, primary, secondary, new class_1792.class_1793()));
}

private static class_2960 id(String path) {
return class_2960.method_60655(LumenDepthsMod.MOD_ID, path);
}

public static void registerEntities() {
LumenDepthsMod.LOGGER.info("[Lumen Depths] Registered 6 entities (+spawn eggs)");
}

public static void registerDefaultAttributes() {
FabricDefaultAttributeRegistry.register(GLOWMOTH, GlowmothEntity.createAttributes().method_26866());
FabricDefaultAttributeRegistry.register(CRYSTAL_SNAIL, CrystalSnailEntity.createAttributes().method_26866());
FabricDefaultAttributeRegistry.register(LUMEN_SPRITE, LumenSpriteEntity.createAttributes().method_26866());
FabricDefaultAttributeRegistry.register(CRYSTAL_BEETLE, CrystalBeetleEntity.createAttributes().method_26866());
FabricDefaultAttributeRegistry.register(SHARD_WRAITH, ShardWraithEntity.createAttributes().method_26866());
FabricDefaultAttributeRegistry.register(GLOOM_MAW, GloomMawEntity.createAttributes().method_26866());
LumenDepthsMod.LOGGER.info("[Lumen Depths] Registered default attributes");
}
}
